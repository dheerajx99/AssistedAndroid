package com.inuom.pickmeup;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PorterDuff;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.android.gms.common.api.Status;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.widget.Autocomplete;
import com.google.android.libraries.places.widget.AutocompleteActivity;
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.inuom.pickmeup.Auth.Details;

import java.sql.Time;
import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import es.dmoral.toasty.Toasty;

import static com.inuom.pickmeup.Tools.getFormattedDate;
import static com.inuom.pickmeup.Tools.getFormattedDateSimple;

public class GiveRide extends AppCompatActivity {

    SharedPreferences sharedPreferences;
    String user_name, user_email, user_phone, user_uid, TAG = "Date", Origin,Destination, Origin_id = "##", Destination_id = "##", Date = "##", Time = "##",Date_db,
            No_ppl = "##";
    long date_ship_millis;
    EditText origin,destination_et;
    Toolbar toolbar;
    int passingers = 1,cost = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_give_ride);
        Tools.setSystemBarColor(this, R.color.orange_500);
        Tools.setSystemBarLight(this);


        toolbar = findViewById(R.id.toolbar);

        toolbar.setNavigationIcon(R.drawable.ic_baseline_arrow_back_24);
        toolbar.getNavigationIcon().setColorFilter(getResources().getColor(android.R.color.white), PorterDuff.Mode.SRC_ATOP);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(null);
        sharedPreferences = getApplicationContext().getSharedPreferences("sp", 0);

        user_name = sharedPreferences.getString(Details.Name, "..");
        user_email = sharedPreferences.getString(Details.Email, "..");
        user_uid = sharedPreferences.getString(Details.UID, "..");
        user_phone = sharedPreferences.getString(Details.Phone, "..");

        origin = findViewById(R.id.origin_et);
        destination_et = findViewById(R.id.destination_et);

        Places.initialize(GiveRide.this,"AIzaSyCEqR9ncQZA7LdsbbOE_vXwFiMQIdsL7Dw");

        origin.setFocusable(false);
        origin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                // Set the fields to specify which types of place data to
                // return after the user has made a selection.
                List<Place.Field> fields = Arrays.asList(Place.Field.ID, Place.Field.NAME);

                // Start the autocomplete intent.
                Intent intent = new Autocomplete.IntentBuilder(AutocompleteActivityMode.OVERLAY, fields)
                        .build(GiveRide.this);
                startActivityForResult(intent, 100);


            }
        });

        destination_et.setFocusable(false);
        destination_et.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                // Set the fields to specify which types of place data to
                // return after the user has made a selection.
                List<Place.Field> fields = Arrays.asList(Place.Field.ID, Place.Field.NAME);

                // Start the autocomplete intent.
                Intent intent = new Autocomplete.IntentBuilder(AutocompleteActivityMode.OVERLAY, fields)
                        .build(GiveRide.this);
                startActivityForResult(intent, 200);


            }
        });

        ((TextView) findViewById(R.id.giveride_pass)).setText(passingers+"");

        findViewById(R.id.giveride_add).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                passingers++;
                ((TextView) findViewById(R.id.giveride_pass)).setText(passingers+"");
            }
        });

        findViewById(R.id.giveride_minus).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (passingers > 1){
                    passingers--;
                    ((TextView) findViewById(R.id.giveride_pass)).setText(passingers+"");
                }

            }
        });

        ((TextView) findViewById(R.id.cost)).setText("$ "+cost+"");

        findViewById(R.id.cost_add).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cost++;
                ((TextView) findViewById(R.id.cost)).setText("$ "+cost+"");
            }
        });

        findViewById(R.id.cost_minus).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (cost > 1){
                    cost--;
                    ((TextView) findViewById(R.id.cost)).setText("$ "+cost+"");
                }

            }
        });


        findViewById(R.id.select_date).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    final android.icu.util.Calendar calendar = android.icu.util.Calendar.getInstance();
                    android.app.DatePickerDialog datePickerDialog = new android.app.DatePickerDialog(GiveRide.this, R.style.datepicker, new android.app.DatePickerDialog.OnDateSetListener() {
                        @RequiresApi(api = Build.VERSION_CODES.N)
                        @Override
                        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                            calendar.set(java.util.Calendar.DAY_OF_MONTH, dayOfMonth);
                            calendar.set(java.util.Calendar.MONTH, monthOfYear);
                            calendar.set(java.util.Calendar.YEAR, year);
                            date_ship_millis = calendar.getTimeInMillis();
                            ((TextView) findViewById(R.id.date_text)).setText(getFormattedDateSimple(date_ship_millis));
                            Date_db = getFormattedDate(date_ship_millis);
                            Date = getFormattedDateSimple(date_ship_millis);
                        }
                    }, calendar.get(java.util.Calendar.YEAR), calendar.get(java.util.Calendar.MONTH), calendar.get(java.util.Calendar.DAY_OF_MONTH));
                    // datePickerDialog.getDatePicker().setMaxDate(calendar.getTimeInMillis());
                    datePickerDialog.show();
                } else {
                    int mYear, mMonth, mDay;
                    Calendar mcurrentDate = Calendar.getInstance();
                    mYear = mcurrentDate.get(Calendar.YEAR);
                    mMonth = mcurrentDate.get(Calendar.MONTH);
                    mDay = mcurrentDate.get(Calendar.DAY_OF_MONTH);
                    date_ship_millis = mcurrentDate.getTimeInMillis();
                    DatePickerDialog mDatePicker = new DatePickerDialog(GiveRide.this, new DatePickerDialog.OnDateSetListener() {
                        public void onDateSet(DatePicker datepicker, int selectedyear, int selectedmonth, int selectedday) {
                            ((TextView) findViewById(R.id.date_text)).setText(getFormattedDateSimple(date_ship_millis));
                            Date = getFormattedDateSimple(date_ship_millis);
                            Date_db = getFormattedDate(date_ship_millis);
                        }
                    }, mYear, mMonth, mDay);
                    mDatePicker.setTitle("Select date");
                    // mDatePicker.getDatePicker().setMaxDate(mcurrentDate.getTimeInMillis());
                    mDatePicker.show();
                }
            }
        });

        findViewById(R.id.select_time).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Calendar mcurrentTime = Calendar.getInstance();
                int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
                int minute = mcurrentTime.get(Calendar.MINUTE);
                TimePickerDialog mTimePicker;
                mTimePicker = new TimePickerDialog(GiveRide.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                        ((TextView) findViewById(R.id.time_text)).setText(gettime(selectedHour, selectedMinute));
                        Time = gettime(selectedHour, selectedMinute);
                    }
                }, hour, minute, false);//Yes 24 hour time
                mTimePicker.setTitle("Select Time");
                mTimePicker.show();

            }
        });

        findViewById(R.id.saveride).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (Origin_id.equals("##")){
                    Toasty.warning(getApplicationContext(), "Please Select Origin", Toast.LENGTH_SHORT, true).show();
                } else if (Destination_id.equals("##")){
                    Toasty.warning(getApplicationContext(), "Please Select Destination", Toast.LENGTH_SHORT, true).show();
                } else if (Date.equals("##")){
                    Toasty.warning(getApplicationContext(), "Please Select Date", Toast.LENGTH_SHORT, true).show();
                } else if (Time.equals("##")){
                    Toasty.warning(getApplicationContext(), "Please Select Time", Toast.LENGTH_SHORT, true).show();
                } else {

                    FirebaseFirestore rides;
                    rides = FirebaseFirestore.getInstance();
                    DocumentReference reference = rides.collection("Rides").document();
                    Map<String, Object> temp2 = new HashMap<>();

                    temp2.put("Origin", Origin);
                    temp2.put("Origin_id",Origin_id);
                    temp2.put("Destination",Destination);
                    temp2.put("Destination_id",Destination_id);
                    temp2.put("Date",Date);
                    temp2.put("Date_DB",Date_db);
                    temp2.put("Time",Time);
                    temp2.put("UID" , user_uid);
                    temp2.put("Name" , user_name);
                    temp2.put("Email" , user_email);
                    temp2.put("Price" , cost+"");
                    temp2.put("Pass",passingers+"");
                    temp2.put("Phone",sharedPreferences.getString(Details.Phone, "....."));


                    reference.set(temp2);

                    FirebaseFirestore fstore;
                    fstore = FirebaseFirestore.getInstance();
                    DocumentReference df = fstore.collection("GiveRide").document("Ride").collection(Date_db).document();
                    Map<String, Object> temp = new HashMap<>();

                    temp.put("Origin", Origin);
                    temp.put("Origin_id",Origin_id);
                    temp.put("Destination",Destination);
                    temp.put("Destination_id",Destination_id);
                    temp.put("Date",Date);
                    temp.put("Date_DB",Date_db);
                    temp.put("Time",Time);
                    temp.put("UID" , user_uid);
                    temp.put("Name" , user_name);
                    temp.put("Email" , user_email);
                    temp.put("Price" , cost+"");
                    temp.put("Pass",passingers+"");


                    df.set(temp);

                    Toasty.success(getApplicationContext(), "Your Ride has been placed", Toast.LENGTH_LONG, true).show();

                }

            }
        });

        {
            DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("GiveRide");
            Query query = databaseReference.orderByKey().limitToLast(1);
            query.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {



                    }

                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable @org.jetbrains.annotations.Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100 && resultCode == RESULT_OK){
            Place place = Autocomplete.getPlaceFromIntent(data);
            origin.setText(place.getName());

            Origin_id = place.getId();
            Origin = place.getName();

        } else if (requestCode == 200 && resultCode == RESULT_OK){
            Place place = Autocomplete.getPlaceFromIntent(data);
            destination_et.setText(place.getName());

            Destination_id = place.getId();
            Destination = place.getName();
        }
        else if(resultCode == AutocompleteActivity.RESULT_ERROR){

            Origin_id = "##";
            Destination_id = "##";
            Status status = Autocomplete.getStatusFromIntent(data);
            Log.d(TAG, "onActivityResult: " + status.getStatusMessage());
        }
    }

    public String gettime(int hr, int min) {
        java.sql.Time tme = new Time(hr, min, 0);//seconds by default set to zero
        Format formatter;
        formatter = new SimpleDateFormat("h:mm a");
        return formatter.format(tme);

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
        }

        return super.onOptionsItemSelected(item);
    }

}