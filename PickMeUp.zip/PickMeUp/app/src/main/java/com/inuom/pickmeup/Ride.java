package com.inuom.pickmeup;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.widget.NestedScrollView;

public class Ride extends AppCompatActivity {

    public TextView mProfile;
    public ImageButton mProfileCallbutton;
    public TextView mProfileName;
    public TextView mProfileEmail;
    public TextView mProfileDate;
    public TextView mProfileNoofseats;
    public TextView mProfileOrigin;
    public TextView mProfileDestination;
    public TextView mProfileBusroute;
    public TextView mProfileOther;
    public TextView mProfileConcession;
    public TextView mProfileConcessionType;
    public NestedScrollView mNestedScrollView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ride);

        setTitle("Ride Details");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        mProfileCallbutton = findViewById(R.id.profile_callbutton);
        mProfileName = findViewById(R.id.profile_name);
        mProfileEmail = findViewById(R.id.profile_email);
        mProfileDate = findViewById(R.id.profile_date);
        mProfileNoofseats = findViewById(R.id.profile_noofseats);
        mProfileOrigin = findViewById(R.id.profile_origin);
        mProfileDestination = findViewById(R.id.profile_destination);

        mNestedScrollView = findViewById(R.id.nested_scroll_view);


        ((TextView) findViewById(R.id.profile_phone)).setText(getIntent().getStringExtra("Phone"));
        ((TextView) findViewById(R.id.profile_address)).setText(getIntent().getStringExtra("Origin") + " to " + getIntent().getStringExtra("Destination"));


        mProfileName.setText(getIntent().getStringExtra("Name"));
        mProfileOrigin.setText(getIntent().getStringExtra("Origin"));
        mProfileDestination.setText(getIntent().getStringExtra("Destination"));
        mProfileEmail.setText(getIntent().getStringExtra("Email"));
        mProfileNoofseats.setText(getIntent().getStringExtra("Pass"));
        mProfileDate.setText(getIntent().getStringExtra("Date"));

        findViewById(R.id.profile_callbutton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Call(getIntent().getStringExtra("Phone"));
            }
        });





    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {

            case 123:
                if ((grantResults.length > 0) && (grantResults[0] == PackageManager.PERMISSION_GRANTED)) {

                } else {
                    Log.d("TAG", "Call Permission Not Granted");
                }
                break;

            default:
                break;
        }
    }

    public void Call(String number) {
        int permissionCheck = ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE);

        if (permissionCheck != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.CALL_PHONE},
                    123);
        } else {
            startActivity(new Intent(Intent.ACTION_CALL).setData(Uri.parse("tel:" + number)));
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
        }

        return super.onOptionsItemSelected(item);
    }

}