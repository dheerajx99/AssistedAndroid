    package com.inuom.pickmeup.Auth;

/*
  Developed by : R.Gnana Sreekar
  Github : https://github.com/gnanasreekar
  Linkdin : https://www.linkedin.com/in/gnana-sreekar/
  Instagram : https://www.instagram.com/gnana_sreekar/
  Website : https://gnanasreekar.com
*/


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.inuom.pickmeup.MainActivity;
import com.inuom.pickmeup.R;
import com.inuom.pickmeup.Tools;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;


public class Signup extends AppCompatActivity {
    public TextInputLayout emailId;
    public TextInputLayout password;
    public TextInputLayout username;
    Button buttom_signup;
    TextView signIn;
    FirebaseAuth firebaseAuth;
    LinearLayout signup;
    String name;
    CharSequence s;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    String TAG = "Tag-Login";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sharedPreferences = getApplicationContext().getSharedPreferences("sp", 0);
        setContentView(R.layout.activity_signup);
        getSupportActionBar().hide();
        setTitle("SignUp");

        Tools.setSystemBarColor(this, R.color.transparent);
        Tools.setSystemBarLight(this);

        firebaseAuth = FirebaseAuth.getInstance();

        {
            emailId = findViewById(R.id.email_signup);
            username = findViewById(R.id.username_signup);
            password = findViewById(R.id.password_signup);
            buttom_signup = findViewById(R.id.button_signup);
            signIn = findViewById(R.id.signin_signup);
            signup = findViewById(R.id.signup_layout);



        }


        buttom_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final String emailID = emailId.getEditText().getText().toString();
                String paswd = password.getEditText().getText().toString();
                name = username.getEditText().getText().toString();

                if (emailID.isEmpty()) {
                    username.setError("Set your Username");
                    username.requestFocus();
                } else if (name.isEmpty()) {
                    emailId.setError("Provide your Email first!");
                    emailId.requestFocus();
                } else if (paswd.isEmpty()) {
                    password.setError("Set your password");
                    password.requestFocus();
                } else if (!(emailID.isEmpty() && paswd.isEmpty() && name.isEmpty())) {


                    firebaseAuth.createUserWithEmailAndPassword(emailID, paswd).addOnCompleteListener(Signup.this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (!task.isSuccessful()) {
                                Toast.makeText(Signup.this.getApplicationContext(),
                                        "SignUp unsuccessful: " + task.getException().getMessage(),
                                        Toast.LENGTH_SHORT).show();
                                Log.d(TAG, "onComplete: " + task.getException());
                            } else {

                                UserProfileChangeRequest profileUpdates = new UserProfileChangeRequest.Builder()
                                        .setDisplayName(name)
                                        .build();

                                task.getResult().getUser().updateProfile(profileUpdates)
                                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {
                                                if (task.isSuccessful()) {
                                                    Log.d("Hekkfdf", "User profile updated.");
                                                }
                                            }
                                        });


                                //Date
                                Date d = new Date();
                                s = DateFormat.format("MMMM d, yyyy HH:mm:ss", d.getTime());

                                //Storing data to display in the Nav bar and in the app
                                SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences("sp", 0);
                                SharedPreferences.Editor editor = sharedPreferences.edit();
                                editor.putString(Details.UID, firebaseAuth.getUid());
                                editor.putString(Details.Name, name);
                                editor.putString(Details.Email, emailID);
                                editor.putString(Details.Phone, ((TextInputLayout) findViewById(R.id.username_Phone)).getEditText().getText().toString());
                                editor.apply();

                                // TODO: 14-12-2020 Test 
                                
                                FirebaseFirestore fstore;
                                fstore = FirebaseFirestore.getInstance();
                                DocumentReference df = fstore.collection("Users").document(firebaseAuth.getUid());
                                Map<String, Object> temp = new HashMap<>();
                                temp.put("Name", name);
                                temp.put("Email", emailID);
                                temp.put("UID", firebaseAuth.getUid());
                                temp.put("Date", s);
                                temp.put("V1", 0);
                                temp.put("V2", 0);
                                temp.put("V3", 0);
                                temp.put("V4", 0);
                                temp.put("Phone", ((TextInputLayout) findViewById(R.id.username_Phone)).getEditText().getText().toString());
                                df.set(temp);

                                //To save data in Firebase Database
                                DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Users/" + firebaseAuth.getUid());
                                databaseReference.child("Name").setValue(name);
                                databaseReference.child("Email").setValue(emailID);
                                databaseReference.child("UID").setValue(firebaseAuth.getUid());
                                databaseReference.child("Date").setValue(s);
                                databaseReference.child("V1").setValue(0);
                                databaseReference.child("V2").setValue(0);
                                databaseReference.child("V3").setValue(0);
                                databaseReference.child("V4").setValue(0);
                                databaseReference.child("V5").setValue(0);
                                databaseReference.child("V6").setValue(0);
                                databaseReference.child("V7").setValue(0);
                                databaseReference.child("Phone").setValue(((TextInputLayout) findViewById(R.id.username_Phone)).getEditText().getText().toString());
                                Intent intent = new Intent(Signup.this, MainActivity.class);
                                intent.putExtra("uid", firebaseAuth.getUid());
                                startActivity(intent);
                                finish();

                            }
                        }
                    });
                } else {
                    Toast.makeText(Signup.this, "Error", Toast.LENGTH_SHORT).show();
                }
            }
        });
        signIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Signup.this, Login.class));
            }
        });

        //For interent dialog
        if (!isNetworkAvailable()) {
            //showCustomDialog();
           // Toasty.error(this, "No internet available", Toast.LENGTH_SHORT,true).show();
        }
    }



    private void firebaseauth(GoogleSignInAccount o) {
        AuthCredential authCredential = GoogleAuthProvider.getCredential(o.getIdToken(), null);
        firebaseAuth.signInWithCredential(authCredential).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    FirebaseUser user = firebaseAuth.getCurrentUser();
                    updateUI(user);
                } else {
                    updateUI(null);
                }
            }
        });
    }

    private void updateUI(FirebaseUser user) {

//            GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(getApplicationContext());
        if (user != null) {

            editor = sharedPreferences.edit();
            editor.putString("uid", user.getUid());
            editor.putString("name", user.getDisplayName());
            editor.putString("email", user.getEmail());
            if (user.getPhotoUrl() != null) {
                editor.putString("pic", user.getPhotoUrl().toString());
                editor.putBoolean("pic_stat", true);
            } else {
                editor.putString("pic", null);
                editor.putBoolean("pic_stat", false);
            }
            editor.apply();

            //To save data in Firebase Database

            DatabaseReference databaseReference = FirebaseDatabase.getInstance(sharedPreferences.getString(Details.DB,Details.Default)).getReference("Users/" + firebaseAuth.getUid());
            databaseReference.child("Name").setValue(user.getDisplayName());
            databaseReference.child("Email").setValue(user.getEmail());
            databaseReference.child("UID").setValue(user.getUid());
            if (user.getPhotoUrl() != null) {
                databaseReference.child("PIC").setValue(user.getPhotoUrl().toString());
                editor.putString("pic", user.getPhotoUrl().toString());
                editor.putBoolean("pic_stat", true);
            } else {
                databaseReference.child("PIC").setValue("");
                editor.putString("pic", null);
                editor.putBoolean("pic_stat", false);
            }
//            Intent intent = new Intent(Signup.this, Detailsinput.class);
//            intent.putExtra("uid", user.getUid());
//            startActivity(intent);
//            finish();


        } else {
            Toast.makeText(this, "Login to continue", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(Signup.this, Login.class));
        finish();
    }

    //    private void showCustomDialog() {
//        final Dialog dialog = new Dialog(this);
//        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE); // before
//        dialog.setContentView(R.layout.nonet_warning);
//        dialog.setCancelable(true);
//
//        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
//        lp.copyFrom(dialog.getWindow().getAttributes());
//        lp.width = WindowManager.LayoutParams.WRAP_CONTENT;
//        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
//
//
//        ((AppCompatButton) dialog.findViewById(R.id.bt_close)).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                finish();
//                dialog.dismiss();
//            }
//        });
//
//        dialog.show();
//        dialog.getWindow().setAttributes(lp);
//    }
//
//    public void showaccountcreatedDialog() {
//        final Dialog dialog = new Dialog(this);
//        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
//        dialog.setContentView(R.layout.acc_confirmed);
//        dialog.setCancelable(true);
//
//        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
//        lp.copyFrom(dialog.getWindow().getAttributes());
//        lp.width = WindowManager.LayoutParams.WRAP_CONTENT;
//        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
//
//        ((AppCompatButton) dialog.findViewById(R.id.bt_close)).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("AuthRequest/" + firebaseAuth.getUid());
//                databaseReference.child("Name").setValue(name);
//                databaseReference.child("Date").setValue(s);
//                finish();
//                dialog.dismiss();
//            }
//        });
//
//        dialog.show();
//        dialog.getWindow().setAttributes(lp);
//    }
}

