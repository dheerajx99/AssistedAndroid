 package com.inuom.pickmeup;


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;


import java.util.List;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {
    private List<RidePojo> listData;
    Context context;
    SharedPreferences sharedPreferences;

    public void setlist(List<RidePojo> listData) {
        this.listData = listData;
    }

    public Adapter(Context context) {
        this.context = context;
        sharedPreferences = context.getSharedPreferences("sp", 0);
        Log.d("TAG", "MyAdapter: " + sharedPreferences.getBoolean("reduceanim" , false));
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.ride_layout, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position)
    {

        if (sharedPreferences.getBoolean("animate" , false)){
            holder.cardView.setAnimation(AnimationUtils.loadAnimation(context,R.anim.fade_trans));
        }


         RidePojo ld = listData.get(position);
         String Origin = ld.getOri();
         String Dest = ld.getDest();
         String Time = ld.getDate();
         String Price = ld.getPrice();
        String pass = ld.getPass();




        holder.address.setText(Origin + " to " + Dest);
        holder.date.setText(Time);
        holder.price.setText("$ "+ Price);
        holder.pass.setText("Available seat: " + pass);

        holder.linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, Ride.class);
                intent.putExtra("Name" , ld.getName());
                intent.putExtra("Date" , ld.getDate());
                intent.putExtra("Origin" , ld.getOri());
                intent.putExtra("Destination" , ld.getDest());
                intent.putExtra("Email" , ld.getEmail());
                intent.putExtra("Pass" , ld.getPass());
                intent.putExtra("Phone" , ld.getPhone());



                context.startActivity(intent);

            }
        });
    }

    @Override
    public int getItemCount() {
        return listData.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView address,price,pass,date;
        CardView cardView;
        LinearLayout linearLayout;

        public ViewHolder(View itemView) {
            super(itemView);

            address = itemView.findViewById(R.id.address);
            price = itemView.findViewById(R.id.price);
            pass = itemView.findViewById(R.id.avilseat);
            date = itemView.findViewById(R.id.time);
            linearLayout = itemView.findViewById(R.id.layout);
            cardView = itemView.findViewById(R.id.cardview);


        }
    }

}