package com.inuom.pickmeup.Auth;


import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.widget.NestedScrollView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.inuom.pickmeup.MainActivity;
import com.inuom.pickmeup.R;
import com.inuom.pickmeup.Tools;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;



public class Login extends AppCompatActivity {

    public TextInputLayout login_username, login_password;
    Button button_login;
    TextView signup, logintext;
    FirebaseAuth firebaseAuth;
    LinearLayout linearLayout, no_net;
    String userEmail;
    int RC_SIGN_IN;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    boolean dataexist = false;
    private String selected_lang;
    private static final String[] Languages = new String[]{
            "English", "Telugu"
    };
    private LinearLayout loginLoading;
    private NestedScrollView loginMain;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        getSupportActionBar().hide();
        Tools.setSystemBarColor(this, R.color.transparent);
        Tools.setSystemBarLight(this);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            Window w = getWindow();
            w.setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        }

        sharedPreferences = getApplicationContext().getSharedPreferences("sp", 0);

        editor = sharedPreferences.edit();
        firebaseAuth = FirebaseAuth.getInstance();
        login_username = findViewById(R.id.username);
        login_password = findViewById(R.id.password);
        button_login = findViewById(R.id.button_login);
        signup = findViewById(R.id.signup);
        linearLayout = findViewById(R.id.login);
        loginLoading = findViewById(R.id.login_loading);
        loginMain = findViewById(R.id.login_main);


        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent I = new Intent(Login.this, Signup.class);
                startActivity(I);
                finish();
            }
        });
        button_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                userEmail = login_username.getEditText().getText().toString();
                String userPaswd = login_password.getEditText().getText().toString();

                if (userEmail.isEmpty()) {
                    login_username.setError("Provide your Email first!");
                    login_username.requestFocus();
                } else if (userPaswd.isEmpty()) {
                    login_password.setError("Enter Password!");
                    login_password.requestFocus();
                } else if (userEmail.isEmpty() && userPaswd.isEmpty()) {
                    Toast.makeText(Login.this, "Fields Empty!", Toast.LENGTH_SHORT).show();
                } else if (!(userEmail.isEmpty() && userPaswd.isEmpty())) {
                    firebaseAuth.signInWithEmailAndPassword(userEmail, userPaswd).addOnCompleteListener(Login.this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (!task.isSuccessful()) {
                                Toast.makeText(Login.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                            } else {

                                ((TextView) findViewById(R.id.login_loading_tv)).setText("Welcome " + task.getResult().getUser().getDisplayName());
                                loginMain.setVisibility(View.GONE);
                                loginLoading.setVisibility(View.VISIBLE);
                                updateUI(task.getResult().getUser());

                            }
                        }
                    });
                } else {
                    Toast.makeText(Login.this, "Error", Toast.LENGTH_SHORT).show();
                }
            }
        });
        login_password.getEditText().setOnEditorActionListener(new TextView.OnEditorActionListener() {
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if ((event != null && (event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) || (actionId == EditorInfo.IME_ACTION_DONE)) {
                    //do what you want on the press of 'done'
                    button_login.performClick();
                }
                return false;
            }
        });



    }


    @Override
    public void onBackPressed() {
        showexitDialog();
    }

    @Override
    protected void onStart() {
        super.onStart();
        FirebaseUser currentUser = firebaseAuth.getCurrentUser();
        if (currentUser != null) {
            ((TextView) findViewById(R.id.login_loading_tv)).setText("Welcome " + currentUser.getDisplayName());
            loginMain.setVisibility(View.GONE);
            loginLoading.setVisibility(View.VISIBLE);
        }
        //  Log.d("Login", "onStart: " + firebaseAuth.getFirebaseAuthSettings().);
        updateUI(currentUser);

    }

    private void updateUI(FirebaseUser user) {

        if (user != null) {
            Log.d("Login", "onStart1q1eqwe: " + user.isAnonymous());

            //  if (!user.isAnonymous()){
            Log.d("Login", "updateUI: " + user.getUid());
            editor.putString(Details.UID, user.getUid());
            editor.putString(Details.Name, user.getDisplayName());
            editor.putString(Details.Email, user.getEmail());

            //To save data in Firebase Database
            DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Users/" + firebaseAuth.getUid());
            databaseReference.child("Name").setValue(user.getDisplayName());
            databaseReference.child("Email").setValue(user.getEmail());
            databaseReference.child("UID").setValue(firebaseAuth.getUid());

            FirebaseFirestore fstore;
            fstore = FirebaseFirestore.getInstance();
            DocumentReference df = fstore.collection("Users").document(firebaseAuth.getUid());
            Map<String, Object> temp = new HashMap<>();

            temp.put("Name", user.getDisplayName());
            temp.put("Email", user.getEmail());
            temp.put("UID", firebaseAuth.getUid());
            temp.put("ProviderId", user.getProviderId());

            df.set(temp);

            if (user.getPhotoUrl() != null) {

                Log.d("311489", "updateUI: " + user.getPhotoUrl());
                databaseReference.child("PIC").setValue(user.getPhotoUrl().toString());
                editor.putString(Details.Pic, user.getPhotoUrl().toString());
                editor.putBoolean("pic_stat", true);
            } else {
                editor.putString(Details.Pic, null);
                editor.putBoolean("pic_stat", false);
            }

            if (user.getPhotoUrl() != null) {
                editor.putString("pic", user.getPhotoUrl().toString());
                editor.putBoolean("pic_stat", true);
            } else {
                editor.putString("pic", null);
                editor.putBoolean("pic_stat", false);
            }
            editor.apply();

            Log.d("1314", "updateUI: 1314 " + user.getDisplayName());

            startActivity(new Intent(Login.this, MainActivity.class));

//            } else {
//                if (getIntent().getBooleanExtra("offline",true)){
//                    startActivity(new Intent(Login.this, NologinMain.class));
//                    finish();
//                }
//            }


        } else {
//            if (getIntent().getBooleanExtra("offline",true)){
//                startActivity(new Intent(Login.this, NologinMain.class));
//                finish();
//            }
//            Toast.makeText(this, "Login to gain all access", Toast.LENGTH_SHORT).show();
        }
    }

    //Forgot password Dialog
    public void forgotpassword(View view) {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE); // before
        dialog.setContentView(R.layout.forgotpass);
        dialog.setCancelable(true);

        final EditText email = dialog.findViewById(R.id.passemail);
        email.setText(userEmail);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.WRAP_CONTENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        ((AppCompatButton) dialog.findViewById(R.id.bt_close)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (email.getText().toString().matches("")) {
                    //Toasty.info(Login.this, "Please Fill email", Toast.LENGTH_SHORT, true).show();
                } else {
                    FirebaseAuth.getInstance().sendPasswordResetEmail(email.getText().toString())
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (task.isSuccessful()) {
                                        Toast.makeText(Login.this, "Please Check your mail!", Toast.LENGTH_SHORT).show();
                                    } else {
                                        Toast.makeText(Login.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });
                }
                dialog.dismiss();
            }
        });

        dialog.show();
        dialog.getWindow().setAttributes(lp);
    }

    //Exit Dialog
//    private void showexitDialog() {
//        final Dialog dialog = new Dialog(this);
//        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE); // before
//        dialog.setContentView(R.layout.exitdialog);
//        dialog.setCancelable(true);
//
//        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
//        lp.copyFrom(dialog.getWindow().getAttributes());
//        lp.width = WindowManager.LayoutParams.WRAP_CONTENT;
//        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
//
//
//        ((AppCompatButton) dialog.findViewById(R.id.bt_close)).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                finish();
//                //  System.exit(0);
//                dialog.dismiss();
//            }
//        });
//
//        dialog.show();
//        dialog.getWindow().setAttributes(lp);
//    }

    //Exit Dialog
    private void showexitDialog() {

        try {

            InputStream is = getAssets().open("Quotes.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            String json = new String(buffer, "UTF-8");
            JSONArray jsonObject = new JSONArray(json);

            Random rand = new Random();


            int rand_int1 = rand.nextInt(jsonObject.length());

            JSONObject jsonObject1 = (JSONObject) jsonObject.get(rand_int1);

            final Dialog dialog = new Dialog(this);
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE); // before
            dialog.setContentView(R.layout.exitdialog);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

            TextView dialogImageTitle;
            TextView dialogImageAuthor;

            dialogImageTitle = dialog.findViewById(R.id.dialog_image_title);
            dialogImageAuthor = dialog.findViewById(R.id.dialog_image_author);

            dialogImageTitle.setText(jsonObject1.getString("text"));
            dialogImageAuthor.setText("-" + jsonObject1.getString("author"));
            dialog.show();
            dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                @Override
                public void onDismiss(DialogInterface dialogInterface) {
                    finish();

                }
            });

          //  Toasty.info(this, "Press back again to exit", Toast.LENGTH_LONG, true).show();

//
//        final Dialog dialog = new Dialog(this);
//        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE); // before
//        dialog.setContentView(R.layout.exitdialog);
//        dialog.setCancelable(true);
//
//        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
//        lp.copyFrom(dialog.getWindow().getAttributes());
//        lp.width = WindowManager.LayoutParams.WRAP_CONTENT;
//        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;


//        ((AppCompatButton) dialog.findViewById(R.id.bt_close)).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                finish();
//                dialog.dismiss();
//            }
//        });

//        dialog.show();
//        dialog.getWindow().setAttributes(lp);
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

//    @Override
//    protected void onPause() {
//        super.onPause();
//        Animatoo.animateSlideLeft(this);
//    }
//
//    @Override
//    protected void onPostResume() {
//        super.onPostResume();
//        Animatoo.animateSlideRight(this);
//    }


}
