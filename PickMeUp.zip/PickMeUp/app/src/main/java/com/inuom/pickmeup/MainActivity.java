package com.inuom.pickmeup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.PorterDuff;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.tasks.OnCanceledListener;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.widget.Autocomplete;
import com.google.android.libraries.places.widget.AutocompleteActivity;
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.inuom.pickmeup.Auth.Details;
import com.inuom.pickmeup.Auth.Login;

import org.jetbrains.annotations.NotNull;

import java.sql.Time;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import es.dmoral.toasty.Toasty;

import static com.inuom.pickmeup.Tools.getFormattedDate;
import static com.inuom.pickmeup.Tools.getFormattedDateSimple;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    NavigationView navView;
    Toolbar toolbar;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    String user_name, user_email, user_pic, user_uid, TAG = "Log_Main", Origin, Destination, Origin_id = "##", Destination_id = "##", Date = "##", Time = "##", Date_db,
            No_ppl = "##";
    LinearLayout loading;
    long date_ship_millis;
    EditText origin, destination_et;
    RecyclerView rv;
    Adapter adapter;
    private List<RidePojo> listData;
    int passingers = 1;
    FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        {
            toolbar = findViewById(R.id.toolbar);

            toolbar.setNavigationIcon(R.drawable.ic_menu);
            toolbar.getNavigationIcon().setColorFilter(getResources().getColor(android.R.color.white), PorterDuff.Mode.SRC_ATOP);
            setSupportActionBar(toolbar);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle(null);
//        Tools.setSystemBarColor(this, R.color.orange_500);
            firebaseAuth = FirebaseAuth.getInstance();

            Tools.setSystemBarColor(this, R.color.transparent);
            Tools.setSystemBarLight(this);

            sharedPreferences = getApplicationContext().getSharedPreferences("sp", 0);
            editor = sharedPreferences.edit();

            editor.putString(Details.Phone, "912-332-4324");
            editor.apply();

            DrawerLayout drawer = findViewById(R.id.drawer_layout);
            navView = findViewById(R.id.nav_view);
            ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                    this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
            drawer.addDrawerListener(toggle);
            toggle.syncState();
            navView.setNavigationItemSelectedListener(this);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                Window w = getWindow();
                w.setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
            }

            adapter = new Adapter(MainActivity.this);
            rv = (RecyclerView) findViewById(R.id.rec_view_main);
            rv.setHasFixedSize(true);
            rv.setLayoutManager(new LinearLayoutManager(this));
            listData = new ArrayList<>();
            listData.clear();

        }

        user_name = sharedPreferences.getString(Details.Name, "..");
        user_email = sharedPreferences.getString(Details.Email, "..");
        user_uid = sharedPreferences.getString(Details.UID, "..");


        {
            loading = findViewById(R.id.loading_main);
            origin = findViewById(R.id.origin_et);
            destination_et = findViewById(R.id.destination_et);
        }



        Places.initialize(MainActivity.this, "AIzaSyCEqR9ncQZA7LdsbbOE_vXwFiMQIdsL7Dw");

        origin.setFocusable(false);
        origin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                // Set the fields to specify which types of place data to
                // return after the user has made a selection.
                List<Place.Field> fields = Arrays.asList(Place.Field.ID, Place.Field.NAME);

                // Start the autocomplete intent.
                Intent intent = new Autocomplete.IntentBuilder(AutocompleteActivityMode.OVERLAY, fields)
                        .build(MainActivity.this);
                startActivityForResult(intent, 100);


            }
        });

        destination_et.setFocusable(false);
        destination_et.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                // Set the fields to specify which types of place data to
                // return after the user has made a selection.
                List<Place.Field> fields = Arrays.asList(Place.Field.ID, Place.Field.NAME);

                // Start the autocomplete intent.
                Intent intent = new Autocomplete.IntentBuilder(AutocompleteActivityMode.OVERLAY, fields)
                        .build(MainActivity.this);
                startActivityForResult(intent, 200);


            }
        });


        findViewById(R.id.select_date).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    final android.icu.util.Calendar calendar = android.icu.util.Calendar.getInstance();
                    android.app.DatePickerDialog datePickerDialog = new android.app.DatePickerDialog(MainActivity.this, R.style.datepicker, new android.app.DatePickerDialog.OnDateSetListener() {
                        @RequiresApi(api = Build.VERSION_CODES.N)
                        @Override
                        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                            calendar.set(java.util.Calendar.DAY_OF_MONTH, dayOfMonth);
                            calendar.set(java.util.Calendar.MONTH, monthOfYear);
                            calendar.set(java.util.Calendar.YEAR, year);
                            date_ship_millis = calendar.getTimeInMillis();
                            ((TextView) findViewById(R.id.date_text)).setText(getFormattedDateSimple(date_ship_millis));
                            Date_db = getFormattedDate(date_ship_millis);
                            Date = getFormattedDateSimple(date_ship_millis);
                        }
                    }, calendar.get(java.util.Calendar.YEAR), calendar.get(java.util.Calendar.MONTH), calendar.get(java.util.Calendar.DAY_OF_MONTH));
                    // datePickerDialog.getDatePicker().setMaxDate(calendar.getTimeInMillis());
                    datePickerDialog.show();
                } else {
                    int mYear, mMonth, mDay;
                    Calendar mcurrentDate = Calendar.getInstance();
                    mYear = mcurrentDate.get(Calendar.YEAR);
                    mMonth = mcurrentDate.get(Calendar.MONTH);
                    mDay = mcurrentDate.get(Calendar.DAY_OF_MONTH);
                    date_ship_millis = mcurrentDate.getTimeInMillis();
                    DatePickerDialog mDatePicker = new DatePickerDialog(MainActivity.this, new DatePickerDialog.OnDateSetListener() {
                        public void onDateSet(DatePicker datepicker, int selectedyear, int selectedmonth, int selectedday) {
                            ((TextView) findViewById(R.id.date_text)).setText(getFormattedDateSimple(date_ship_millis));
                            Date = getFormattedDateSimple(date_ship_millis);
                            Date_db = getFormattedDate(date_ship_millis);
                        }
                    }, mYear, mMonth, mDay);
                    mDatePicker.setTitle("Select date");
                    // mDatePicker.getDatePicker().setMaxDate(mcurrentDate.getTimeInMillis());
                    mDatePicker.show();
                }
            }
        });

        findViewById(R.id.select_time).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Calendar mcurrentTime = Calendar.getInstance();
                int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
                int minute = mcurrentTime.get(Calendar.MINUTE);
                TimePickerDialog mTimePicker;
                mTimePicker = new TimePickerDialog(MainActivity.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                        ((TextView) findViewById(R.id.time_text)).setText(gettime(selectedHour, selectedMinute));
                        Time = gettime(selectedHour, selectedMinute);
                    }
                }, hour, minute, false);//Yes 24 hour time
                mTimePicker.setTitle("Select Time");
                mTimePicker.show();

            }
        });

        navviewdata();

        ((TextView) findViewById(R.id.takeride_pass)).setText(passingers+"");

        findViewById(R.id.takeride_add).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                passingers++;
                if (passingers > 5){
                    Toasty.info(getApplicationContext(), "Seriously, More than 5     !!!", Toast.LENGTH_SHORT, true).show();
                }
                ((TextView) findViewById(R.id.takeride_pass)).setText(passingers+"");
            }
        });

        findViewById(R.id.takeride_minus).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (passingers > 1){
                    passingers--;
                    ((TextView) findViewById(R.id.takeride_pass)).setText(passingers+"");
                } else {
                    Toasty.error(getApplicationContext(), "Can't go any low than 1", Toast.LENGTH_SHORT, true).show();
                }

            }
        });

        findViewById(R.id.pickmeup).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (Origin_id.equals("##")) {
                    Toasty.warning(getApplicationContext(), "Please Select Origin", Toast.LENGTH_SHORT, true).show();
                } else if (Destination_id.equals("##")) {
                    Toasty.warning(getApplicationContext(), "Please Select Destination", Toast.LENGTH_SHORT, true).show();
                } else if (Date.equals("##")) {
                    Toasty.warning(getApplicationContext(), "Please Select Date", Toast.LENGTH_SHORT, true).show();
                } else if (Time.equals("##")) {
                    Toasty.warning(getApplicationContext(), "Please Select Time", Toast.LENGTH_SHORT, true).show();
                } else {

                    FirebaseFirestore db = FirebaseFirestore.getInstance();
                    db.collection("Rides").whereEqualTo("Origin_id", Origin_id).whereEqualTo("Date_DB",Date_db).get()
                            .addOnCanceledListener(new OnCanceledListener() {
                        @Override
                        public void onCanceled() {
                            Log.d(TAG, "onCanceled: ");
                        }
                    }).addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull @NotNull Task<QuerySnapshot> task) {

                            if (task.isSuccessful()) {
                                findViewById(R.id.SelectRide).setVisibility(View.INVISIBLE);
                                findViewById(R.id.AvailRide).setVisibility(View.VISIBLE);

                                ((TextView)findViewById(R.id.no_rides_avail)).setText("No of rides available: " + task.getResult().size());

                                for (QueryDocumentSnapshot document : task.getResult()) {
                                    Log.d(TAG, document.getId() + " => " + document.getData());
                                    Toast.makeText(MainActivity.this, document.getString("Date"), Toast.LENGTH_SHORT).show();

                                    listData.add(new RidePojo(document.getString("Date"),
                                            document.getString("Date_DB"),
                                            document.getString("Destination"),
                                            document.getString("Destination_id"),
                                            document.getString("Origin"),
                                            document.getString("Origin_id"),
                                            document.getString("Pass"),
                                            document.getString("Time"),
                                            document.getString("UID"),
                                            document.getString("Name"),
                                            document.getString("Price"),
                                            document.getString("Email"),
                                            document.getString("Phone")));
                                    adapter.setlist(listData);
                                    rv.setAdapter(adapter);

                                }
                            } else {
                                Log.d(TAG, "Error getting documents: ", task.getException());
                            }

                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull @NotNull Exception e) {
                            Log.d(TAG, "onFailure: " + e.getMessage());
                        }
                    });

//                    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Rides/" + sharedPreferences.getString(Details.UID, "...") + "/" + Date_db);
//                    String key = databaseReference.push().getKey();
//
//                    databaseReference.child(key).child("Origin").setValue(Origin);
//                    databaseReference.child(key).child("Origin_id").setValue(Origin_id);
//                    databaseReference.child(key).child("Destination_id").setValue(Destination_id);
//                    databaseReference.child(key).child("Destination").setValue(Destination);
//                    databaseReference.child(key).child("Date").setValue(Date);
//                    databaseReference.child(key).child("Date_DB").setValue(Date_db);
//                    databaseReference.child(key).child("Time").setValue(Time);
//                    databaseReference.child(key).child("Pass").setValue(((EditText) findViewById(R.id.noofpass)).getText().toString());

                    //Toasty.success(getApplicationContext(), "Your request has been placed", Toast.LENGTH_LONG, true).show();

                }

            }
        });

    }




    @SuppressLint("NewApi")
    private boolean hasPermissions(String... permissions) {
        if (permissions != null) {
            for (String permission : permissions) {
                if (MainActivity.this.checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
                    return false;
                }
            }
        }
        return true;
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable @org.jetbrains.annotations.Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100 && resultCode == RESULT_OK) {
            Place place = Autocomplete.getPlaceFromIntent(data);

            Log.d(TAG, "onActivityResult: " + place.toString());

            origin.setText(place.getName());

            Origin_id = place.getId();
            Origin = place.getName();

        } else if (requestCode == 200 && resultCode == RESULT_OK) {
            Place place = Autocomplete.getPlaceFromIntent(data);
            destination_et.setText(place.getName());

            Destination_id = place.getId();
            Destination = place.getName();
        } else if (resultCode == AutocompleteActivity.RESULT_ERROR) {

            Origin_id = "##";
            Destination_id = "##";
            Status status = Autocomplete.getStatusFromIntent(data);
            Log.d(TAG, "onActivityResult: " + status.getStatusMessage());
        }
    }

    public String gettime(int hr, int min) {
        Time tme = new Time(hr, min, 0);//seconds by default set to zero
        Format formatter;
        formatter = new SimpleDateFormat("h:mm a");
        return formatter.format(tme);

    }


    public void navviewdata() {
        View nav_view = navView.getHeaderView(0);

        TextView nav_h_n = nav_view.findViewById(R.id.nav_header_name);
        TextView nav_h_s = nav_view.findViewById(R.id.nav_header_secondary);
        ImageView imageView = nav_view.findViewById(R.id.nav_header_imageView);
        RelativeLayout image = nav_view.findViewById(R.id.header_image);
        if (android.os.Build.VERSION.SDK_INT > android.os.Build.VERSION_CODES.N) {
            image.setBackground(ContextCompat.getDrawable(MainActivity.this, R.drawable.bg_polygon));

        } else {
            image.setBackground(ContextCompat.getDrawable(MainActivity.this, R.drawable.material_bg_1));
        }

        if (sharedPreferences.getBoolean("pic_stat", false)) {
            Glide.with(this).load(sharedPreferences.getString(Details.Pic, Details.Default)).into(imageView);
        } else {
            Glide.with(this).load(R.drawable.ic_male).into(imageView);
        }

        nav_h_n.setText(user_name);
        nav_h_s.setText(user_email);

        setTitle("Hey, " + user_name);
    }

    public void signoutDialog() {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE); // before
        dialog.setContentView(R.layout.signout);
        dialog.setCancelable(true);

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.WRAP_CONTENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;


        dialog.findViewById(R.id.bt_close).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                firebaseAuth.signOut();
                startActivity(new Intent(MainActivity.this, Login.class));
                finish();
                dialog.dismiss();
            }
        });

        dialog.show();
        dialog.getWindow().setAttributes(lp);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull @org.jetbrains.annotations.NotNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_about) {
            startActivity(new Intent(MainActivity.this, About.class));
        } else if (id == R.id.nav_giveride) {
            startActivity(new Intent(MainActivity.this, GiveRide.class));
        } else if (id == R.id.nav_signout) {
            signoutDialog();
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

}