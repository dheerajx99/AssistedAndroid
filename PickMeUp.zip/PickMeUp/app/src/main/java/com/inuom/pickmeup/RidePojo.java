package com.inuom.pickmeup;

public class RidePojo {

    String Date,Date_db,Dest,Dest_db,Ori,Ori_id,Pass,Time,UID,Name,Price,email,phone;

    public RidePojo(String date, String date_db, String dest, String dest_db, String ori, String ori_id, String pass, String time, String UID, String name, String price, String email, String phone) {
        Date = date;
        Date_db = date_db;
        Dest = dest;
        Dest_db = dest_db;
        Ori = ori;
        Ori_id = ori_id;
        Pass = pass;
        Time = time;
        this.UID = UID;
        Name = name;
        Price = price;
        this.email = email;
        this.phone = phone;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getDate_db() {
        return Date_db;
    }

    public void setDate_db(String date_db) {
        Date_db = date_db;
    }

    public String getDest() {
        return Dest;
    }

    public void setDest(String dest) {
        Dest = dest;
    }

    public String getDest_db() {
        return Dest_db;
    }

    public void setDest_db(String dest_db) {
        Dest_db = dest_db;
    }

    public String getOri() {
        return Ori;
    }

    public void setOri(String ori) {
        Ori = ori;
    }

    public String getOri_id() {
        return Ori_id;
    }

    public void setOri_id(String ori_id) {
        Ori_id = ori_id;
    }

    public String getPass() {
        return Pass;
    }

    public void setPass(String pass) {
        Pass = pass;
    }

    public String getTime() {
        return Time;
    }

    public void setTime(String time) {
        Time = time;
    }

    public String getUID() {
        return UID;
    }

    public void setUID(String UID) {
        this.UID = UID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getPrice() {
        return Price;
    }

    public void setPrice(String price) {
        Price = price;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
