package com.inuom.pickmeup.Auth;

public class Details {
    public static final String DB = "database";
    public static String Name = "name";
    public static String Email = "email";
    public static String UID = "uid";
    public static String ID = "ID";
    public static String Pic = "pic";
    public static String Default = "...";
    public static String Phone = "Phone";

    public static String Address = "Address";
    public static String Transition = "Transition";

    public static String Lang = "Language";
    public static String API_KEY = "your_api_key";

}
