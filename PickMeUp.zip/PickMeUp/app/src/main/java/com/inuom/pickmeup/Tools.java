package com.inuom.pickmeup;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.util.DisplayMetrics;
import android.view.Menu;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.ColorInt;
import androidx.annotation.ColorRes;
import androidx.core.content.ContextCompat;
import androidx.core.widget.NestedScrollView;

import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;


public class Tools {

    public static void setSystemBarColor(Activity act) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = act.getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.setStatusBarColor(act.getResources().getColor(R.color.colorPrimaryDark));
        }
    }

    public static void setSystemBarColor(Activity act, @ColorRes int color) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = act.getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.setStatusBarColor(act.getResources().getColor(color));
        }
    }

    public static void nestedScrollTo(final NestedScrollView nested, final View targetView) {
        nested.post(new Runnable() {
            @Override
            public void run() {
                nested.scrollTo(500, targetView.getBottom());
            }
        });
    }

    public static void hideKeyboard(Activity activity) {
        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        //Find the currently focused view, so we can grab the correct window token from it.
        View view = activity.getCurrentFocus();
        //If no view currently has focus, create a new one, just so we can grab a window token from it
        if (view == null) {
            view = new View(activity);
        }
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    public static void changeMenuIconColor(Menu menu, @ColorInt int color) {
        for (int i = 0; i < menu.size(); i++) {
            Drawable drawable = menu.getItem(i).getIcon();
            if (drawable == null) continue;
            drawable.mutate();
            drawable.setColorFilter(color, PorterDuff.Mode.SRC_ATOP);
        }
    }

    public static void setAppLocale(String localeCode, Activity acc){
        Resources resources = acc.getResources();
        DisplayMetrics dm = resources.getDisplayMetrics();
        Configuration config = resources.getConfiguration();
        if (Build.VERSION.SDK_INT>= Build.VERSION_CODES.JELLY_BEAN_MR1){
            config.setLocale(new Locale(localeCode.toLowerCase()));
        } else {
            config.locale = new Locale(localeCode.toLowerCase());
        }
        resources.updateConfiguration(config, dm);
    }

    public static boolean isNetworkAvailable(Activity acc) {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) acc.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

//    public static void snackbarNointernet(Activity acc) {
//        final Snackbar snackbar = Snackbar.make(acc.getWindow().getDecorView().getRootView(), "", Snackbar.LENGTH_LONG);
//        //inflate view
//        View custom_view = acc.getLayoutInflater().inflate(R.layout.snackbar_toast_floating_dark, null);
//
//        snackbar.getView().setBackgroundColor(Color.TRANSPARENT);
//        Snackbar.SnackbarLayout snackBarView = (Snackbar.SnackbarLayout) snackbar.getView();
//        snackBarView.setPadding(0, 0, 0, 0);
//
//        (custom_view.findViewById(R.id.no_net_wifi)).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                acc.startActivity(new Intent(android.provider.Settings.ACTION_WIFI_SETTINGS));
//            }
//        });
//
//        (custom_view.findViewById(R.id.mobile_data)).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                acc.startActivity(new Intent(android.provider.Settings.ACTION_WIRELESS_SETTINGS));
//            }
//        });
//
//        snackBarView.addView(custom_view, 0);
//        snackbar.show();
//    }

    public static void setSystemBarLight(Activity act) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            View view = act.findViewById(android.R.id.content);
            int flags = view.getSystemUiVisibility();
            flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            view.setSystemUiVisibility(flags);
        }
    }

    public static void setSystemBarTransparent(Activity act) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = act.getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.DKGRAY);
        }
    }

    //Thus, 10 Mar 2018
    public static String getFormattedDateSimple(Long dateTime) {
        SimpleDateFormat newFormat = new SimpleDateFormat("EEE, d MMM yy");
        return newFormat.format(new Date(dateTime));
    }

    public static String getFormattedDate(Long dateTime) {
        SimpleDateFormat newFormat = new SimpleDateFormat("dd-MM-yyyy");
        return newFormat.format(new Date(dateTime));
    }

    public static String getIntfromMon(String mon) {
        String m="";
        DateFormatSymbols dfs = new DateFormatSymbols();
        String[] months = dfs.getMonths();
        for (int i = 0; i < months.length; i++) {
            //   Log.d(TAG, "onDataChange:--0   " + i + "  " + months[i]);
            if (months[i].equals(mon)){
                ++i;
                if (!(i==10 || i == 11 || i == 12)){
                    m =  "0" + i;
                } else {
                    m = ""+i;
                }
            }

        }
        return m;
    }

//    public static void ErrorDialog(Activity act, final String toString, final String s) {
//
//        final DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Errors");
//        String key = databaseReference.push().getKey();
//
//        SharedPreferences sharedPreferences = act.getSharedPreferences("sp", 0);
//
//        final Dialog dialog = new Dialog(act);
//        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE); // before
//        dialog.setContentView(R.layout.dialog_image_error);
//        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
//
//        View dialogImageview;
//        ImageView dialogImageImage;
//        TextView dialogImageTitle;
//        TextView dialogImageAuthor;
//
//        dialogImageview = dialog.findViewById(R.id.dialog_image_view);
//        dialogImageImage = dialog.findViewById(R.id.dialog_image_image);
//        dialogImageTitle = dialog.findViewById(R.id.dialog_image_title);
//        dialogImageAuthor = dialog.findViewById(R.id.dialog_image_author);
//
//        dialogImageview.setBackground(ContextCompat.getDrawable(act, R.color.red_200));
//        dialogImageTitle.setText("Something went wrong!");
//        dialogImageAuthor.setText("- MRMS");
//
//       dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
//           @Override
//           public void onDismiss(DialogInterface dialogInterface) {
//               databaseReference.child(key).child(s).setValue(toString);
//               databaseReference.child(key).child("name").setValue(sharedPreferences.getString(Details.Name, Details.Default));
//               databaseReference.child(key).child("uid").setValue(sharedPreferences.getString(Details.UID, Details.Default));
//               databaseReference.child(key).child("V").setValue(BuildConfig.VERSION_NAME);
//           }
//       });
//
//        dialog.show();
//
////        AlertDialog.Builder builder = new AlertDialog.Builder(act, R.style.ErrorDialogStyle);
////        builder.setTitle("Something went wrong! ");
////        builder.setMessage("There seems to be an error please report this issure and contace the administrator");
////        builder.setPositiveButton("Report", new DialogInterface.OnClickListener() {
////            @Override
////            public void onClick(DialogInterface dialogInterface, int i) {
////
////            }
////        });
////        builder.setNegativeButton("Back",  new DialogInterface.OnClickListener() {
////            @Override
////            public void onClick(DialogInterface dialogInterface, int i) {
////                databaseReference.child(key).child(s).setValue(toString);
////                databaseReference.child(key).child("name").setValue(sharedPreferences.getString(Details.Name, Details.Default));
////                databaseReference.child(key).child("uid").setValue(sharedPreferences.getString(Details.UID, Details.Default));
////                databaseReference.child(key).child("V").setValue(BuildConfig.VERSION_NAME);
////            }
////        });
////        builder.setOnDismissListener(new DialogInterface.OnDismissListener() {
////            @Override
////            public void onDismiss(DialogInterface dialogInterface) {
////                databaseReference.child(key).child(s).setValue(toString);
////                databaseReference.child(key).child("name").setValue(sharedPreferences.getString(Details.Name, Details.Default));
////                databaseReference.child(key).child("uid").setValue(sharedPreferences.getString(Details.UID, Details.Default));
////                databaseReference.child(key).child("V").setValue(BuildConfig.VERSION_NAME);
////            }
////        });
////
////        builder.show();
//
//    }



}
